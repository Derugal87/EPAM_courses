package by.epam.gift.entity;

import java.util.Objects;

/**
 * @param name
 * @param manufacture
 * @param amountSugar
 * @param weight
 * @param price
 * @author ALDER
 */
public class Candy {
	private String name;
	private String manufacture;
	private double amountSugar;
	private double weight;
	private double price;
	
	public Candy(String name, String manufacture, double amountSugar,
			double weigth, double price) {
		this.name = name;
		this.manufacture = manufacture;
		this.amountSugar = amountSugar;
		this.weight = weigth;
		this.price = price;
		
		setName(name);
		setManufacture(manufacture);
		setAmountSugar(amountSugar);
		setWeight(weigth);
		setPrice(price);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		if (name == null){
			throw new IllegalArgumentException("Wrong parameter of name! name can't be null!");
	}
	}

	public String getManufacture() {
		return manufacture;
	}

	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
		if (name == null){
			throw new IllegalArgumentException("Wrong parameter of manufacture! manufacture can't be null!");
	}
	}

	public double getAmountSugar() {
		return amountSugar;
	}

	public void setAmountSugar(double amountSugar) {
		this.amountSugar = amountSugar;
		if (amountSugar < 0.0){
			throw new IllegalArgumentException("Wrong parameter of amountSugar! amountSugar can't be less than 0.0");
		}
	}

	public double getWeight() {
		return weight;
		
	}

	public void setWeight(double weight) {
		this.weight = weight;
		if (weight < 0.0){
			throw new IllegalArgumentException("Wrong parameter of weight! weight can't be less than 0.0");
		}
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
		if (price < 0.0){
			throw new IllegalArgumentException("Wrong parameter of price! price can't be less than 0.0");
		}
	}

	/**
	 * Overriding equals(), hashCode(), toString()
	 */

	@Override
	public boolean equals(Object otherObject) {

	
		if (this == otherObject) {
			return true;
		}
	
		if (otherObject == null) {
			return false;
		}
	
		if (getClass() != otherObject.getClass()) {
			return false;
		}
	
		Candy other = (Candy) otherObject;
		
		return Objects.equals(name, other.name)
				&& Objects.equals(manufacture, other.manufacture)
				&& amountSugar == other.amountSugar
				&& weight == other.weight && price == other.price;

	}

	@Override
	public int hashCode() {
		return Objects.hash(name, manufacture, amountSugar, weight, price);
	}

	@Override
	public String toString() {
		return getClass().getName() + "[name = " + name + ",manufacture = "
				+ manufacture + ",amountSugar = " + amountSugar
				+ ",weight = " + weight + ",price = " + price + "]";
	}

}
