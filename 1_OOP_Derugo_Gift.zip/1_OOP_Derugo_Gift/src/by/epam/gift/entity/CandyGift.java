package by.epam.gift.entity;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @param gift
 * @author ALDER
 *
 */

public class CandyGift {

	private List<Candy> gift;

	public CandyGift() {
		this.gift = new ArrayList<Candy>();
	}

	public void addCandy(Candy otherCandy) {
		gift.add(otherCandy);
	}

	public void addCandies(Collection<Candy> otherCandy) {
		gift.addAll(otherCandy);
	}

	public List<Candy> getCandies() {
		return gift;
	}

	/**
	 * Overriding equals(), hashCode(), toString()
	 */

	@Override
	public boolean equals(Object otherObject) {

		if (this == otherObject) {
			return true;
		}

		if (otherObject == null) {
			return false;
		}

		if (getClass() != otherObject.getClass()) {
			return false;
		}

		CandyGift other = (CandyGift) otherObject;

		return Objects.equals(gift, other.gift);

	}

	@Override
	public int hashCode() {
		return Objects.hash(gift);
	}

	@Override
	public String toString() {
		return getClass().getName() + "[gift = " + gift + "]";
	}

}
