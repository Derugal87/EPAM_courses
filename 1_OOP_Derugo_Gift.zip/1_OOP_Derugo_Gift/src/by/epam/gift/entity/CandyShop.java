package by.epam.gift.entity;

public class CandyShop {

	
	public static Candy chooseCandy(CandyTypes type){
		
		switch(type){
		case BARBARIS:
			return new Caramels("Barbaris", "Zdravushka", 70.0, 20.0, 30.0, "red", "barbaris");
		case ALENKA:
			return new ChocolateCandy("Alenka", "Kommunarka", 120.0, 25.0, 40.0, 25.0, "black");
		case SORVANETC:
			return new ChocolateCandy("Sorvanetc", "Kommunarka", 300.0, 30.0, 30.0, 18.0, "milk");
		case DUSHES:
			return new Caramels("Dushes", "Spartak", 230.0, 25.0, 40.0, "green", "pear");
		case ASSORTI:
			return new Caramels("Assorti", "Roshen", 20.0, 25.0, 40.0, "yellow", "limon");
		case MASKA:
			return new ChocolateCandy("Maska", "Spartak", 80.0, 35.0, 40.0, 28.0, "white");
		default:
			throw new IllegalArgumentException();
		}
		
	}
}
	
