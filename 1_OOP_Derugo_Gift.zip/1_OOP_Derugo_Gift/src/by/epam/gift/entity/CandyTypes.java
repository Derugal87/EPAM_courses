package by.epam.gift.entity;

public enum CandyTypes {
	BARBARIS, ALENKA, SORVANETC, DUSHES, ASSORTI, MASKA
}
