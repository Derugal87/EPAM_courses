package by.epam.gift.entity;

import java.util.Objects;

/**
 * @param color;
 * @param flavor;
 * @author ALDER
 */

public class Caramels extends Candy {
	private String color;
	private String flavor;
	
	public Caramels(String name, String manufacture, double amountSugar,
			double weight, double price, String color, String flavor) {
		super(name, manufacture, amountSugar, weight, price);
		this.color = color;
		this.flavor = flavor;
		setColor(color);
		setFlavor(flavor);
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
		if (color == null){
			throw new IllegalArgumentException("Wrong parameter of color! color can't be null!");
	}
	}

	public String getFlavor() {
		return flavor;
	}

	public void setFlavor(String flavor) {
		this.flavor = flavor;
		if (flavor == null){
			throw new IllegalArgumentException("Wrong parameter of color! color can't be null!");
	}
	}

	/**
	 * Overriding equals(), hashCode(), toString()
	 */

	@Override
	public boolean equals(Object otherObject) {

		if (!super.equals(otherObject)) {
			return false;
		}

		Caramels other = (Caramels) otherObject;

		return Objects.equals(color, other.color)
				&& Objects.equals(flavor, other.flavor);
	}

	@Override
	public int hashCode() {
		return super.hashCode() + 17 * new String(color).hashCode() + 23
				* new String(flavor).hashCode();
	}

	@Override
	public String toString() {
		return super.toString() + "[color = " + color + ",flavor = " + flavor
				+ "]";
	}

}
