package by.epam.gift.entity;

import java.util.Objects;

/**
 * @param amountCocoa;
 * @param typeChocolate; // only "black", "milk", "white"
 * @author ALDER
 */

public class ChocolateCandy extends Candy {

	private double amountCocoa; 
	private String typeChocolate; 
	
	public ChocolateCandy(String name, String manufacture,
			double amountSugar, double weight, double price,
			double amountCocoa, String typeChocolate) {
		super(name, manufacture, amountSugar, weight, price);
		
		this.amountCocoa = amountCocoa;
		this.typeChocolate = typeChocolate;
		setAmountCocoa(amountCocoa);
		setTypeChocolate(typeChocolate);
	}

	public double getAmountCocoa() {
		return amountCocoa;
	}

	public void setAmountCocoa(double amountCocoa) {
		this.amountCocoa = amountCocoa;
		if (amountCocoa < 0.0){
			throw new IllegalArgumentException("Wrong parameter of amountCocoa! amountCocoa must be most than 0.0");
		}
	}

	public String getTypeChocolate() {
		return typeChocolate;
	}

	public void setTypeChocolate(String typeChocolate) {
		this.typeChocolate = typeChocolate;
		if (!"black".equals(typeChocolate) && !"milk".equals(typeChocolate) && !"white".equals(typeChocolate) || typeChocolate == null){
			throw new IllegalArgumentException("Wrong parameter of typeChocolate! typeofChocolate must be black, milk or white!");
	}
}
	/**
	 * Overriding equals(), hashCode(), toString()
	 */

	@Override
	public boolean equals(Object otherObject) {

		if (!super.equals(otherObject)) {
			return false;
		}

		ChocolateCandy other = (ChocolateCandy) otherObject;

		return amountCocoa == other.amountCocoa
				&& Objects.equals(typeChocolate, other.typeChocolate);
	}

	@Override
	public int hashCode() {
		return super.hashCode() + 17 * new Double(amountCocoa).hashCode()
				+ 23 * new String(typeChocolate).hashCode();
	}

	@Override
	public String toString() {
		return super.toString() + "[amountOfCocoa = " + amountCocoa
				+ ",typeOfChocolate = " + typeChocolate + "]";
	}

}
