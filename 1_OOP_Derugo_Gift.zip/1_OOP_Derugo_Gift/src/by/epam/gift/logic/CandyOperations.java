package by.epam.gift.logic;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import by.epam.gift.entity.Candy;
import by.epam.gift.entity.CandyGift;
import by.epam.gift.entity.CandyTypes;

public class CandyOperations {

	public CandyGift createNewGift() {
		return new CandyGift();
	}

	public <Gift> void addCandy(Gift gift, CandyTypes type) {
	}

	public static double calculateWeight(CandyGift candyGift) {
		double weight = 0.0;
		List<Candy> gift = candyGift.getCandies();
		Iterator<Candy> iter = gift.iterator();
		while (iter.hasNext()) {
			Candy everyCandy = iter.next();
			weight = weight + everyCandy.getWeight();
		}
		return weight;
	}

	public static void sort(CandyGift candyGift,
			Comparator<Candy> candyComparator) {
		List<Candy> gift = candyGift.getCandies();
		Collections.sort(gift, candyComparator);
	}
	
	public static Candy findCandy(CandyGift candyGift, double amountSugarMin,
			double amountSugarMax) {
		List<Candy> gift = candyGift.getCandies();
		Iterator<Candy> iter = gift.iterator();
		while (iter.hasNext()) {
			Candy everyCandy = iter.next();
			if (everyCandy.getAmountSugar() >= amountSugarMin
					& everyCandy.getAmountSugar() <= amountSugarMax) {
				return everyCandy;
			}
		}
		return null;
	}



}
