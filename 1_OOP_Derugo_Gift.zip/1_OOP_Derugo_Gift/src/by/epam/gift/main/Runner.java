package by.epam.gift.main;
/**
 * In this program we're gathering candyChristmas gift;
 */

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.log4j.Logger;

import by.epam.gift.entity.Candy;
import by.epam.gift.entity.CandyComparator;
import by.epam.gift.entity.CandyGift;
import by.epam.gift.entity.CandyShop;
import by.epam.gift.entity.CandyTypes;
import by.epam.gift.logic.CandyOperations;

public class Runner {

	static {
		  new DOMConfigurator().doConfigure("log4j.xml", LogManager.getLoggerRepository());
		 }
	
	static Logger logger = Logger.getLogger(Runner.class);
	
	
	public static void main(String[] args) {
		logger.info("test start");
		

		// Creating candies-objects (all types)
		
		Candy barbaris = CandyShop.chooseCandy(CandyTypes.BARBARIS);
		Candy alenka = CandyShop.chooseCandy(CandyTypes.ALENKA);
		Candy sorvanetc = CandyShop.chooseCandy(CandyTypes.SORVANETC);
		Candy dushes = CandyShop.chooseCandy(CandyTypes.DUSHES);
		Candy assorti = CandyShop.chooseCandy(CandyTypes.ASSORTI);
		Candy maska = CandyShop.chooseCandy(CandyTypes.MASKA);
	

		// Gathering candyList
		List<Candy> candyList = new ArrayList<Candy>();
		candyList.add(alenka);
		candyList.add(sorvanetc);
		candyList.add(dushes);
		candyList.add(assorti);
		candyList.add(maska);

		// Gathering candyChristmas gift
		CandyGift childGift = new CandyGift();
		childGift.addCandy(barbaris);
		childGift.addCandies(candyList);

		// Defining candyGiftWeight
		logger.info("Test1.Defining candyGiftWeight:");
		logger.debug("Weight of gift = "
				+ CandyOperations.calculateWeight(childGift));

		// Sorting by name
		logger.info("Test2.Sorting by name:");
		CandyOperations.sort(childGift, new CandyComparator());
		logger.debug(childGift);

		// Searching candy limited by sugarDiapasone
		logger.info("Test3. Searching candy limited by sugarDiapasone:");
		Candy foundCandy = CandyOperations.findCandy(childGift, 5.0, 10.0);
		if (foundCandy != null) {
			logger.debug("Candy with amount of sugar 20.0 - 50.0 = "
					+ foundCandy.getName());
		} else {
			logger.debug("Candy is not found");
		}
		logger.info("test end");
	}
}
