package by.epam.parking.car;

import java.util.Calendar;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;


import by.epam.parking.poll.Resource;
import by.epam.parking.poll.ResourcePool;

public class Car extends Thread {

	static Logger logger = Logger.getLogger(Car.class);
	
	private boolean haveResource;
    private ResourcePool pool;
    private long timeWaiting;
   	private Lock lock = new ReentrantLock();
 
    public Car(long timeWaiting) {
    	this.timeWaiting = timeWaiting;
    }
   	
   	public Car(ResourcePool pool, long timeWaiting) {
        this.pool = pool;
        this.timeWaiting = timeWaiting;
    }
 

    
/**
 * ������ ����
 */
    
    @Override
    public void run() {
 
        Resource parkingPlace = null;
        logger.info(Calendar.getInstance().getTime() + "--> " + "Car #" + this.getId() + " in a queue");
       
        lock.lock();  
        try {
            boolean havePlace = pool.getResource(getTimeWaiting());
           
           if (havePlace) {
                parkingPlace = pool.getResource();
                haveResource = true;
                logger.debug(Calendar.getInstance().getTime() + "--> " + "Car #" + this.getId()
                        + " get resource : " + parkingPlace.getResourceId());
                parkingPlace.using();

            } else {
            	 logger.debug(Calendar.getInstance().getTime() + "--> " + "Car #" + this.getId() + " have no time to wait for resource");
            }
         } catch (InterruptedException e) {
				logger.debug("error while taking resource (car)");
        } finally {
            if (parkingPlace != null) {
                haveResource = false;
                logger.debug(Calendar.getInstance().getTime() + "--> " + "Car #" + this.getId() + " released resource : "
                        + parkingPlace.getResourceId());
                pool.returnResource(parkingPlace);
            }
            lock.unlock();
        }
        
    }
 
    public boolean haveResource() {
        return haveResource;
    }
 
    /**
     * @return the timeWaiting
     */
    public long getTimeWaiting() {
        return timeWaiting;
    }
 
}

