package by.epam.parking.main;

import org.apache.log4j.LogManager;
import org.apache.log4j.xml.DOMConfigurator;

import by.epam.parking.car.Car;
import by.epam.parking.poll.ResourcePool;

public class Runner {
 
	static {
		  new DOMConfigurator().doConfigure("log4j.xml", LogManager.getLoggerRepository());
		 }
	
	
    public static void main(String[] args) {
        ResourcePool parking = new ResourcePool(5);       
 
        for(int i = 0; i < 20; i++){
        	parking.setCarIntoQueue(new Car(100));
        }
 
        parking.openResourcePoll();
    }
}

