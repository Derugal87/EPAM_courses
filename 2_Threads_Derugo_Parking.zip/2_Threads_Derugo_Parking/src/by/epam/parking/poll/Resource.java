package by.epam.parking.poll;

import java.util.Random;

import org.apache.log4j.Logger;

public class Resource {

	static Logger logger = Logger.getLogger(Resource.class);
	
	private int resourceId;
 
    public Resource(int id) {
        this.resourceId = id;
    }
 
    public Resource() {
    }
 
    public int getResourceId() {
        return resourceId;
    }
 
    public void setResourceId(int id) {
        this.resourceId = id;
    }
 
    /**
     * �������� ������ �� ��������� �����
     */
    public void using() {
        try {
            Thread.sleep(new Random().nextInt(200));
        } catch (InterruptedException e) {
            logger.debug("error with using a parkingPlace... ");
        }
    }
}

