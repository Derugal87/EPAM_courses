package by.epam.composite.entity;

import java.util.Iterator;

public interface Component {
  
    public Component getElement(int index);
 
    public void parse();
 
    public Iterator<Component> getIterator();
}
