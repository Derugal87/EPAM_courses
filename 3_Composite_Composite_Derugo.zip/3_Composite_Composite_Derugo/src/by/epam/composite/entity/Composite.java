package by.epam.composite.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import by.epam.composite.entity.Component;
 
public class Composite implements Component {
    private List<Component> list = new ArrayList<>();
 
    public Composite() {
    }
 

    public void addElement(Component component) {
        list.add(component);
 
    }
 
    
    public void removeElement(Component component) {
        list.remove(component);
    }
 
    @Override
    public Component getElement(int index) {
        return list.get(index);
    }
 
    @Override
    public void parse() {
 
    }
 
    @Override
    public Iterator<Component> getIterator() {
        return list.iterator();
    }
 
}
