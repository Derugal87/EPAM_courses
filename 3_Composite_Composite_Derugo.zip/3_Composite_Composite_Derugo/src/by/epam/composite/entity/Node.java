package by.epam.composite.entity;

import java.util.Iterator;

import by.epam.composite.entity.Component;
 
public class Node implements Component {
 
    private String str;
 
    public Node(String str) {
        this.str = str;
    }
 
 
    @Override
    public Component getElement(int index) {
        return this;
    }
 
    @Override
    public void parse() {
        throw new UnsupportedOperationException();
    }
 
    @Override
    public Iterator<Component> getIterator() {
        throw new UnsupportedOperationException();
 
    }
 
    @Override
    public String toString() {
        return str;
    }
}
