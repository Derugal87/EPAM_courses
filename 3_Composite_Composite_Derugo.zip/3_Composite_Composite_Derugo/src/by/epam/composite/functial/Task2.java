package by.epam.composite.functial;
/**
 * ������ 2: ������� ��� ����������� ��������� ������ � ������� ����������� ���������� ���� � ������ �� ���.
 * ����� �� ������ Runner.
 */

import java.util.LinkedList;
import java.util.List;
import org.apache.log4j.Logger;
import java.util.Arrays;
 
public class Task2 implements Comparable<Task2> {
    	
	static Logger logger = Logger.getLogger(Task2.class); 
	
	public static final String SENTENCE_ENDS = ".!?";
    public static final String WORD_DELIMITERS = " \t\n\\,-_+*/@%#";
 
    private String text;
    private int words;
 
    public Task2(String t) {
        text = t;
        words = ( t.split("[" + WORD_DELIMITERS + SENTENCE_ENDS + "]") ).length;
    }
 
    @Override
    public String toString() {
        return text;
    }
 
    @Override
    public int compareTo(Task2 another) {
        return words - another.words;
    }
 
    
 
    public static void program() {
        
    	// Result from TextParcer
    	String text = 
"Calling constructors from constructors.\n" +
"When you write several constructors for a class, there are times when you�d like to call one constructor from another to avoid duplicating code.\n"+
"You can do this using the this keyword.\n" +
"Normally, when you say this, it is in the sense of �this object� or �the current object,� and by itself it produces the reference to the current object.\n" +
"In a constructor, the this keyword takes on a different meaning when you give it an argument list: it makes an explicit call to the constructor that matches that argument list.\n" +
"Thus you have a straightforward way to call other constructors\n" +
"The constructor Flower(String s, int petals) shows that, while you can call one constructor using this, you cannot call two.\n" +
"In addition, the constructor call must be the first thing you do or you�ll get a compiler error message.\n" +
"This example also shows another way you�ll see this used.\n" +
"Since the name of the argument s and the name of the member data s are the same, there�s an ambiguity.\n" +
"You can resolve it by saying this to refer to the member data.\n" +
"You�ll often see this form used in Java code, and it�s used in numerous places in this book.\n" +
"In print( ) you can see that the compiler won�t let you call a constructor from inside any method other than a constructor.";
 
        logger.info("Unsorted:\n" + text);
 
        Task2[] sentences = Task2.toSentencesArray(text);
        Arrays.sort(sentences);
        logger.info("Sorted:");
        for ( Task2 s : sentences )
        	logger.debug(s);
    }

 
    
    public static Task2[] toSentencesArray(String input) {
        StringBuilder builder = new StringBuilder();
        List<Task2> list = new LinkedList<Task2>();
 
        for ( char c : input.toCharArray() ) {
            if ( c == '\n' )
                c = ' ';
            builder.append(c);
            if ( SENTENCE_ENDS.indexOf(c) > -1 ) {
                list.add(new Task2(builder.toString().trim()));
                builder = new StringBuilder();
            }
        }
 
        return list.toArray(new Task2[list.size()]);
    }
}
    
    
   
