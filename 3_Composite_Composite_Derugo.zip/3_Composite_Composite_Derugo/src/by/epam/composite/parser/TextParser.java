package by.epam.composite.parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import by.epam.composite.entity.Composite;
import by.epam.composite.entity.Node;
 
public class TextParser {
 
	static Logger logger = Logger.getLogger(TextParser.class); 

    public TextParser() {}
 
    public Composite parse(String path) {
        String text = init(path);
        Composite wholeText = new Composite();
        wholeText = parseToParagraph(wholeText, text);
        return wholeText;
    }
 
    private String init(final String path) {
        String text = "";
        try {
            FileInputStream inFile = new FileInputStream(path);
            byte[] str = new byte[inFile.available()];
            inFile.read(str);
            text = new String(str); 
        } catch (FileNotFoundException e) {
            logger.warn("File Is Not Found!");
        } catch (IOException e) {
        	logger.warn("Mistake!");
        }
        return text;
    }
 
    private Composite parseToParagraph(Composite wholeText, String text) {
        // parse to paragraph
        Composite paragraphList = new Composite();
        Pattern patternParagraph = Pattern.compile(Types.REGEX_PARAGRAPH_WITH_LISTING);
        Node paragraphLeaf = null;
        String paragraph = "";
        //logger.info("\n" + text); // show all text
        Matcher matcher = patternParagraph.matcher(text);
        while (matcher.find()) {
            paragraph = matcher.group();
            if (Pattern.matches(Types.REGEX_LISTING, paragraph)) {
                paragraphLeaf = new Node(paragraph);
                //logger.debug(paragraphLeaf); // show only listing
                paragraphList.addElement(paragraphLeaf);
            } else {
                //logger.debug(paragraph); // show only paragraph
                paragraphList = parseToSentense(paragraphList, paragraph);
            }
            wholeText.addElement(paragraphList);
        }
 
        return wholeText;
    }
 
    private Composite parseToSentense(Composite paragraphList,
            String paragraph) {
        // parse to sentence
        Composite sentenceList = new Composite();
        Pattern patternSentence = Pattern.compile(Types.REGEX_SENTENCE);
        Matcher m2 = patternSentence.matcher(paragraph);
        String sentence = "";
        while (m2.find()) {
            sentence = m2.group();
            sentenceList = parseToSignAndWord(sentenceList, sentence);
            //logger.debug(sentence); // show all sentences
            paragraphList.addElement(sentenceList);
        }
        return paragraphList;
    }
 
    private Composite parseToSignAndWord(Composite wordList, String word) {
        // parse to sign and word
        Pattern pattern = Pattern.compile(Types.REGEX_WORD_AND_SIGN);
        String wordSign = "";
        Matcher matcher = pattern.matcher(word);
        Composite wordSignList = new Composite();
        while (matcher.find()) {
            wordSign = matcher.group();
            //logger.debug(wordSign); // show all words and signs
            wordSignList = parseToWord(wordSignList, wordSign);
            wordList.addElement(wordSignList);
        }
        return wordList;
    }
    
    private Composite parseToWord(Composite sentenceList,
            String sentence) {
        // parse to word
        Pattern patternWord = Pattern.compile(Types.REGEX_WORD);
        String word = "";
        Matcher matcher = patternWord.matcher(sentence);
        Composite wordList = new Composite();
        while (matcher.find()) {
            word = matcher.group();
            //logger.debug(word); // show only words
            wordList = parseToSymbol(wordList, word);
            sentenceList.addElement(wordList);
        }
        return sentenceList;
    }
 
    
 
    private Composite parseToSymbol(Composite wordSignList,
            String wordSign) {
        // parse to symbol
        Pattern pattern = Pattern.compile(Types.REGEX_SYMBOL);
        String symbol = "";
        Matcher matcher = pattern.matcher(wordSign);
        Node symbolList;
        while (matcher.find()) {
            symbol = matcher.group();
            symbolList = new Node(symbol);
            logger.debug(symbol); // show only symbols
        }
        return wordSignList;
    }
 
}
