package by.epam.composite.parser;

public class Types {
		
	public static final String REGEX_LISTING = "\\s*(Start listing)([^\\t]+)(End listing)";
    public static final String REGEX_PARAGRAPH_WITH_LISTING = "(\\s*(.+))([^(\\s*(Start listing)([^\\t]+)(End listing)\\s)])|\\s*(Start listing)([^\\t]+)(End listing)";
    public static final String REGEX_SENTENCE = "([�-�A-Z]((.[A-Za-z|\\d]|\\n)|[^?!.\\(]|\\([^\\)]*\\))*([\\. |? |! |:\\n]))";
    public static final String REGEX_WORD_AND_SIGN = "([^(\\s)]*)(\\s)*";
    public static final String REGEX_WORD = "[A-Za-z]+";
    public static final String REGEX_SYMBOL = ".{1}";
}
