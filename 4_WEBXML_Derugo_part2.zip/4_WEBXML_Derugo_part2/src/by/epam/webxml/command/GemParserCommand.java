package by.epam.webxml.command;

import by.epam.webxml.entity.Gem;
import by.epam.webxml.entity.GemSpecial;
import by.epam.webxml.entity.GemsType;
import by.epam.webxml.factory.GemBuilderFactory;
import by.epam.webxml.logic.AbstractGemBuilder;
import by.epam.webxml.resource.ConfigurationManager;
import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;


public class GemParserCommand implements ICommand{

    @Override
    public String execute(HttpServletRequest request) {

        String page = null;

        String command = request.getParameter("parser");

        if (command == null || command.isEmpty()) {
            return ConfigurationManager.getProperty("path.page.index");
        }

        GemBuilderFactory factory = new GemBuilderFactory();
        AbstractGemBuilder builder = factory.createGemBuilder(command);       
        String path = request.getServletContext().getRealPath("/");                             
        builder.buildGemSet(path + ConfigurationManager.getProperty("path.page.resource"));   

        HashSet<GemsType> gem = builder.getGemSet();      

        request.setAttribute("gemList", takeAllGem(gem));
        request.setAttribute("gemSpecialList", takeAllGemSpecial(gem));
        request.setAttribute("parsType", command.toUpperCase());

        page = ConfigurationManager.getProperty("path.page.result");    

        return page;
    }


    private HashSet<GemsType> takeAllGem(HashSet<GemsType> gem) {

        HashSet<GemsType> sortGem = new HashSet<>();

        for(GemsType elem : gem) {
            if (elem.getClass() == Gem.class) {
                sortGem.add(elem);
            }
        }
        return sortGem;
    }

    private HashSet<GemsType> takeAllGemSpecial(HashSet<GemsType> gem) {

        HashSet<GemsType> sortGem = new HashSet<>();

        for(GemsType elem : gem) {
            if (elem.getClass() == GemSpecial.class) {
                sortGem.add(elem);
            }
        }
        return sortGem;
    }
}


