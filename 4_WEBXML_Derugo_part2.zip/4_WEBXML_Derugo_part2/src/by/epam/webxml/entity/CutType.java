package by.epam.webxml.entity;

public enum CutType {
    CABOCHON, FACET
}
