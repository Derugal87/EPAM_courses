package by.epam.webxml.entity;

public class Gem extends GemsType {

    private double price;

    public double getPrice() {
        return price;
    }

    public void setPrice(double value) {
        this.price = value;
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) { return false; }

        Gem ref = (Gem)obj;

        return Double.compare(price, ref.getPrice()) == 0 ? true : false;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        long temp;
        temp = Double.doubleToLongBits(getPrice());
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Gem{");
        sb.append(super.toString());
        sb.append("price=").append(price);
        sb.append('}');
        return sb.toString();
    }
}


