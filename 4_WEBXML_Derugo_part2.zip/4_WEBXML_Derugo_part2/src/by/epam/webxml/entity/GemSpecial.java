package by.epam.webxml.entity;

public class GemSpecial extends GemsType {

    private String pointDelivery;

    public String getPointDelivery() {
        return pointDelivery;
    }

    public void setPointDelivery(String value) {
        this.pointDelivery = value;
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) { return false; }

        GemSpecial ref = (GemSpecial)obj;


        if (getPointDelivery() != null ? !getPointDelivery().equals(ref.getPointDelivery()) : ref.getPointDelivery() != null)
                return false;
        return false;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (getPointDelivery() != null ? getPointDelivery().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("GemSpecial{");
        sb.append(super.toString());
        sb.append("pointDelivery=").append(pointDelivery);
        sb.append('}');
        return sb.toString();
    }
}

