package by.epam.webxml.entity;

public abstract class GemsType {

    private int gemId;
    private String status;
    private String gemName;
    private PreciousnessType preciousness;
    private String origin;
    private double value;
    private Parameters visualParameters;

    public GemsType() {
        visualParameters = new Parameters();
    }


    public int getGemId() {
        return gemId;
    }

    public void setGemId(int gemId) {
        this.gemId = gemId;
    }

    public String getGemName() {
        return gemName;
    }

    public void setGemName(String value) {
        this.gemName = value;
    }

    public PreciousnessType getPreciousness() {
        return preciousness;
    }

    public void setPreciousness(PreciousnessType value) {
        this.preciousness = value;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String value) {
        this.origin = value;
    }

    public Parameters getVisualParameters() {
        return visualParameters;
    }


    public void setVisualParameters(Parameters value) {
        this.visualParameters = value;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String value) {
        this.status = value;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        GemsType ref = (GemsType) obj;

        if (Integer.compare(ref.getGemId(), getGemId()) != 0) return false;
        if (getGemName() != null ? !getGemName().equals(ref.getGemName()) : ref.getGemName() != null)
            return false;
        if (preciousness != ref.getPreciousness()) { return false; }   
        if (getOrigin() != null ? !getOrigin().equals(ref.getOrigin()) : ref.getOrigin() != null)
            return false;
        if (Double.compare(value, ref.getValue()) != 0) { return false; }
        if (getStatus() != null ? !getStatus().equals(ref.getStatus()) : ref.getStatus() != null)
            return false;
        return this.visualParameters.equals(ref.getVisualParameters());

    }


    @Override
    public int hashCode() {
        int result = 0;
        long temp;
        result = 31 * result + getGemId();
        result = 31 * result + (getGemName() != null ? getGemName().hashCode() : 0);
        result = 31 * result + (getPreciousness() != null ? getPreciousness().hashCode() : 0);
        result = 31 * result + (getOrigin() != null ? getOrigin().hashCode() : 0);
        temp = Double.doubleToLongBits(getValue());
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (getStatus() != null ? getStatus().hashCode() : 0);
        result = 31 * result + (getVisualParameters() != null ? getVisualParameters().hashCode() : 0);
        return result;
    }



    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("gemId=").append(gemId);
        sb.append(", gemName='").append(gemName).append('\'');
        sb.append(", preciousness=").append(preciousness);
        sb.append(", origin='").append(origin).append('\'');
        sb.append(", value=").append(value).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", visualParameters=").append(visualParameters);
        sb.append('}');
        return sb.toString();
    }

    public class Parameters {

        private String color;
        private int transparency;
        private CutType gemCut;
        private int faces;


        public String getColor() {
            return color;
        }

        public void setColor(String value) {
            this.color = value;
        }

        public int getTransparency() {
            return transparency;
        }

        public void setTransparency(int value) {
            this.transparency = value;
        }

        public CutType getGemCut() {
            return gemCut;
        }

        public void setGemCut(CutType value) {
            this.gemCut = value;
        }

        public int getFaces() {
            return faces;
        }

        public void setFaces(int value) {
            this.faces = value;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;

            Parameters ref = (Parameters) obj;

            if (getColor() != null ? !getColor().equals(ref.getColor()) : ref.getColor() != null)
                return false;
            if (Integer.compare(transparency, ref.getTransparency()) != 0) { return false; }
            if (gemCut != ref.getGemCut()) { return false; }      
            if (Integer.compare(faces, ref.getFaces()) != 0) { return false; };
            return false;

        }


        @Override
        public int hashCode() {
            int result = 0;
            result = 31 * result + (getColor() != null ? getColor().hashCode() : 0);
            result = 31 * result + getTransparency();
            result = 31 * result + (getGemCut() != null ? getGemCut().hashCode() : 0);
            result = 31 * result + getFaces();
            return result;
        }



        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("color=").append(color);
            sb.append(", transparency='").append(transparency).append('\'');
            sb.append(", gemCut=").append(gemCut);
            sb.append(", faces='").append(faces);
            sb.append('}');
            return sb.toString();
        }
    }

}