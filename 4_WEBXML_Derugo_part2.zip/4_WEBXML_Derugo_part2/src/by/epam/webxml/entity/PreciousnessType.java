package by.epam.webxml.entity;

public enum PreciousnessType {
    PRECIOUS, SEMIPRECIOUS
}
