package by.epam.webxml.factory;

import by.epam.webxml.logic.AbstractGemBuilder;
import by.epam.webxml.logic.DOMGemBuilder;
import by.epam.webxml.logic.SAXGemBuilder;
import by.epam.webxml.logic.StAXGemBuilder;

public class GemBuilderFactory {
    private enum TypeParser {
        SAX, STAX, DOM
    }

    public AbstractGemBuilder createGemBuilder(String typeParser) {
        TypeParser type = TypeParser.valueOf(typeParser.toUpperCase());
        AbstractGemBuilder builder = null;

        switch (type) {
            case SAX:
                builder = new SAXGemBuilder();
                break;
            case STAX:
                builder = new StAXGemBuilder();
                break;
            case DOM:
                builder = new DOMGemBuilder();
                break;
            default:
                throw new EnumConstantNotPresentException(type.getDeclaringClass(), type.name());
        }

        return builder;
    }
}


