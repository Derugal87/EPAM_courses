package by.epam.webxml.logic;

import by.epam.webxml.entity.GemsType;

import java.util.HashSet;

public abstract class AbstractGemBuilder {

    private HashSet<GemsType> gemSet;

    public AbstractGemBuilder() {
        gemSet = new HashSet<>();
    }

    public AbstractGemBuilder(HashSet<GemsType> gemSet) {
        this.gemSet = gemSet;
    }

    public HashSet<GemsType> getGemSet() {
        return gemSet;
    }

    public abstract void buildGemSet(String filePath);
}

