package by.epam.webxml.logic;

//import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import by.epam.webxml.entity.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.HashSet;


public class DOMGemBuilder extends AbstractGemBuilder{
    //  private static final Logger LOGGER = Logger.getLogger(DOMGemBuilder.class);
    private HashSet<GemsType> gemSet;
    private DocumentBuilder documentBuilder;

    public DOMGemBuilder() {
        gemSet = new HashSet<>();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            documentBuilder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
//          LOGGER.error(e);
        }
    }
    @Override
    public HashSet<GemsType> getGemSet() { return gemSet; }

    @Override
    public void buildGemSet(String filePath) {
        Document document = null;

        try {
            document = documentBuilder.parse(filePath);
        } catch (IOException e) {
//          LOGGER.error(e);
        } catch (SAXException exp) {
//          LOGGER.error(exp);
        }

        Element rootElement = document.getDocumentElement();    

        NodeList gemList = rootElement.getElementsByTagName("gem"); 
        NodeList specialList = rootElement.getElementsByTagName("gem-special"); 

        addAllGem(gemList);
        addAllSpecial(specialList);
    }

    private void addAllGem(NodeList gemList) {
        for(int index = 0; index < gemList.getLength(); index ++) {
            Element gemElement = (Element)gemList.item(index);
            Gem gem = buildGem(gemElement);
            gemSet.add(gem);
        }
    }

    private void addAllSpecial(NodeList specialList) {
        for(int index = 0; index < specialList.getLength(); index ++) {
            Element gemElement = (Element)specialList.item(index);
            GemSpecial special = buildSpecial(gemElement);
            gemSet.add(special);
        }
    }

    private Gem buildGem (Element gemElement) {
        Gem gem = new Gem();

        buildGemsType(gem, gemElement); 

        double price = Double.parseDouble(getElementTextContent(gemElement, "price"));


        gem.setPrice(price);

        return gem;
    }

    private GemSpecial buildSpecial (Element specialElement) {
        GemSpecial special = new GemSpecial();

        buildGemsType(special, specialElement); 

        String pointDelivery = getElementTextContent(specialElement, "point-delivery");
        special.setPointDelivery(pointDelivery);

        return special;
    }

    private void buildGemsType(GemsType gemsType, Element element) {

        GemsType.Parameters visualParameters = gemsType.getVisualParameters();

        int gemId = Integer.parseInt(element.getAttribute("id"));
        String gemName = getElementTextContent(element, "gem-name");
        String preciousness = getElementTextContent(element, "preciousness");
        String origin = getElementTextContent(element, "origin");
        double value = Double.parseDouble(getElementTextContent(element, "value"));
        String status = element.getAttribute("status");

        String color = getElementTextContent(element, "color");
        int transparency = Integer.parseInt(getElementTextContent(element, "transparency"));
        String gemCut = getElementTextContent(element, "gem-cut");
        int faces = Integer.parseInt(getElementTextContent(element, "faces"));

        gemsType.setGemId(gemId);
        gemsType.setGemName(gemName);
        gemsType.setPreciousness(PreciousnessType.valueOf(preciousness.toUpperCase()));
        gemsType.setOrigin(origin);
        gemsType.setValue(value);
        gemsType.setStatus(status);

        visualParameters.setColor(color);
        visualParameters.setTransparency(transparency);
        visualParameters.setGemCut(CutType.valueOf(gemCut.toUpperCase()));
        visualParameters.setFaces(faces);

    }

    private String getElementTextContent(Element gemElement, String elemName) {
        NodeList list = gemElement.getElementsByTagName(elemName);
        Node node = list.item(0);
        String content = node.getTextContent();
        return content;
    }
}

