package by.epam.webxml.logic;


public enum GemEnum {
    GEM_NAME,
    PRECIOUSNESS_TYPE,
    PRECIOUSNESS,
    ORIGIN,
    VALUE,
    PARAMETERS,
    COLOR,
    TRANSPARENCY,
    GEM_CUT,
    FACES,
    POINT_DELIVERY,
    PRICE,
    GEM,
    GEM_SPECIAL,
    CUT_TYPE,
    GEMS,
    VISUAL_PARAMETERS
}
