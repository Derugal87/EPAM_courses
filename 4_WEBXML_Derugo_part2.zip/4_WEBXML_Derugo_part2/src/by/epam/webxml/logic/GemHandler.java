package by.epam.webxml.logic;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import by.epam.webxml.entity.CutType;
import by.epam.webxml.entity.Gem;
import by.epam.webxml.entity.GemSpecial;
import by.epam.webxml.entity.GemsType;
import by.epam.webxml.entity.PreciousnessType;

//import org.apache.log4j.Logger;
import java.util.HashSet;


public class GemHandler extends DefaultHandler{
    //  private static final Logger LOGGER = Logger.getLogger(GemHandler.class);
    private HashSet<GemsType> gemSet;
    private GemsType current;
    private StringBuilder builder;

    public GemHandler() {
        gemSet = new HashSet<GemsType>();
    }

    public HashSet<GemsType> getGemSet() {
        return gemSet;
    }

    @Override
    public void startDocument() throws SAXException{
//      LOGGER.debug("Start SAX parsing");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        if ("gem".equals(localName)) {
            current = new Gem();
            //read attributes
            int id = Integer.parseInt(attributes.getValue(0));
            current.setGemId(id);                               
            current.setStatus(attributes.getValue(1));              

        } else if ("gem-special".equals(localName)) {
            current = new GemSpecial();
            //read attributes
            int id = Integer.parseInt(attributes.getValue(0));
            current.setGemId(id);                               
            current.setStatus(attributes.getValue(1));             
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        builder = new StringBuilder();
        builder.append(ch, start, length);                              
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        
        if ("gem".equals(localName) || "gem-special".equals(localName)) {
            gemSet.add(current);
        }

        String elementName = localName.replace('-','_').toUpperCase(); 
        GemEnum currentEnum = GemEnum.valueOf(elementName);

        switch (currentEnum) {
            case GEM_NAME:
                current.setGemName(builder.toString());
                break;
            case PRECIOUSNESS:
                PreciousnessType preType = PreciousnessType.valueOf(builder.toString().toUpperCase());
                ((GemsType) current).setPreciousness(preType);
                break;
            case ORIGIN:
                current.setOrigin(builder.toString());
                break;
            case VALUE:
                ((GemsType) current).setValue(Double.parseDouble(builder.toString()));
                break;
            case COLOR:
                current.getVisualParameters().setColor(builder.toString());
                break;
            case TRANSPARENCY:
                ((GemsType) current).getVisualParameters().setTransparency(Integer.parseInt(builder.toString()));
                break;
            case GEM_CUT:
                CutType cutType = CutType.valueOf(builder.toString().toUpperCase());
                ((GemsType) current).getVisualParameters().setGemCut(cutType);
                break;
            case FACES:
                ((GemsType) current).getVisualParameters().setFaces(Integer.parseInt(builder.toString()));
                break;
            case POINT_DELIVERY:
                ((GemSpecial) current).setPointDelivery(builder.toString());
                break;
            case PRICE:
                ((Gem) current).setPrice(Double.parseDouble(builder.toString()));
                break;
        }
        builder = null;
    }

    @Override
    public void endDocument() throws SAXException {
//      LOGGER.debug("End SAX parsing");
    }

}


