package by.epam.webxml.logic;

import java.io.IOException;
import java.util.HashSet;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import by.epam.webxml.entity.GemsType;


public class SAXGemBuilder extends AbstractGemBuilder{

    //  private static final Logger LOGGER = Logger.getLogger(SAXGemBuilder.class);
    private HashSet<GemsType> gemSet;
    private GemHandler handler;
    private XMLReader reader;

    public SAXGemBuilder() {
        handler = new GemHandler();

        try {
            reader  = XMLReaderFactory.createXMLReader();
            reader.setContentHandler(handler);
        } catch (SAXException e) {
//          LOGGER.error(e);
        }
    }

    @Override
    public HashSet<GemsType> getGemSet() {
        return gemSet;
    }

    @Override
    public void buildGemSet(String filePath) {
        //SAX parsing


        try {
            reader.parse(filePath);
        } catch (IOException e) {
//          LOGGER.error(e);
        } catch (SAXException exp) {
//          LOGGER.error(exp);;
        }
        gemSet = handler.getGemSet();
    }


}


