package by.epam.webxml.logic;

import by.epam.webxml.entity.*;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashSet;
//import org.apache.log4j.Logger;


public class StAXGemBuilder extends AbstractGemBuilder{

    //  private static final Logger LOGGER = Logger.getLogger(StAXGemBuilder.class);
    private HashSet<GemsType> gemSet;
    private XMLInputFactory inputFactory;

    public StAXGemBuilder() {
        gemSet = new HashSet<>();
        inputFactory = XMLInputFactory.newInstance();
    }

    @Override
    public HashSet<GemsType> getGemSet() {
        return gemSet;
    }

    @Override
    public void buildGemSet(String filePath) {
        XMLStreamReader xmlReader = null;
        String elementName;

        try(FileInputStream inputStream = new FileInputStream(new File(filePath));) {

            xmlReader = inputFactory.createXMLStreamReader(inputStream);

      
            while(xmlReader.hasNext()) {
                int typeValue = xmlReader.next();

              
                if (typeValue == XMLStreamConstants.START_ELEMENT) {
                    elementName =  xmlReader.getLocalName();            
                    GemEnum currentEnum = GemEnum.valueOf(elementName.replace('-', '_').toUpperCase());   

                    switch (currentEnum) {
                        case GEM:
                            Gem gem = buildGem(xmlReader);
                            gemSet.add(gem);
                            break;
                        case GEM_SPECIAL:
                            GemSpecial special = buildSpecial(xmlReader);
                            gemSet.add(special);
                            break;
                    }
                }
            }

        } catch (XMLStreamException e) {
//          LOGGER.error(e);
        } catch (IOException exp) {
            throw new RuntimeException(exp);
        }

    }

    
    private Gem buildGem(XMLStreamReader xmlReader) throws XMLStreamException {
        Gem gem = new Gem();

        buildGemsType(gem, xmlReader);         
//      LOGGER.debug("Gem: general field are filled in");


        String elementName;

        while(xmlReader.hasNext()) {
            int type = xmlReader.next();
            switch (type) {
                case XMLStreamConstants.START_ELEMENT:
                    elementName = xmlReader.getLocalName();         
                    GemEnum gemEnumStart = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    if (gemEnumStart == GemEnum.PRICE) {
                        elementName = getXMLText(xmlReader);
                        gem.setPrice(Double.parseDouble(elementName));
                    }
                    break;
                case XMLStreamConstants.END_ELEMENT:
                    elementName = xmlReader.getLocalName();         
                    GemEnum gemEnumEnd = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    if (gemEnumEnd == GemEnum.GEM) {
                        return gem;
                    }
                    break;
            }
        }

        throw new XMLStreamException("Unknown element in tag Gem");

    }

    
    private GemSpecial buildSpecial(XMLStreamReader xmlReader) throws XMLStreamException {
        GemSpecial special = new GemSpecial();

        buildGemsType(special, xmlReader);         

        String elementName;

        while(xmlReader.hasNext()) {
            int type = xmlReader.next();

            switch (type) {
                case XMLStreamConstants.START_ELEMENT:
                    elementName = xmlReader.getLocalName();     
                    GemEnum gemEnumStart = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    if (gemEnumStart == GemEnum.POINT_DELIVERY) {
                        special.setPointDelivery(getXMLText(xmlReader));
                    }

                    break;
                case XMLStreamConstants.END_ELEMENT:
                    elementName = xmlReader.getLocalName();       
                    GemEnum gemEnumEnd = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    if (gemEnumEnd == GemEnum.POINT_DELIVERY) {
                        return special;
                    }
                    break;
            }
        }

        throw new XMLStreamException("Unknown element in tag GemSpecial");

    }

   
    private void buildGemsType(GemsType gemsType, XMLStreamReader xmlReader) throws XMLStreamException {

        boolean isEnough = false;

        gemsType.setGemId(Integer.parseInt(xmlReader.getAttributeValue(null, "id")));
        gemsType.setStatus(xmlReader.getAttributeValue(null, "status"));

        String elementName;

        while(xmlReader.hasNext()) {
            int value = xmlReader.next();

            switch (value) {
                case XMLStreamConstants.START_ELEMENT:

                    elementName = xmlReader.getLocalName();         
                    GemEnum gemEnumStart = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());
                    switch (gemEnumStart) {
                        case GEM_NAME:
                            gemsType.setGemName(getXMLText(xmlReader));
                            break;
                        case PRECIOUSNESS:
                            elementName = getXMLText(xmlReader);
                            gemsType.setPreciousness(PreciousnessType.valueOf(elementName.toUpperCase()));
                            break;
                        case ORIGIN:
                            gemsType.setOrigin(getXMLText(xmlReader));
                            break;
                        case VISUAL_PARAMETERS:
                            gemsType.setVisualParameters(getXMLParameters(gemsType, xmlReader));  
                            break;
                        case VALUE:
                            gemsType.setValue(Double.parseDouble(getXMLText(xmlReader)));
                            break;

                    }

                    break;

                case XMLStreamConstants.END_ELEMENT:

                    elementName = xmlReader.getLocalName();            
                    GemEnum gemEnumEnd = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    if (gemEnumEnd == GemEnum.VALUE) {
                        isEnough = true;
                    }

                    break;
            }

            
            if (isEnough) {
                break;
            }
        }
    }

    
    private GemsType.Parameters getXMLParameters (GemsType gemsType, XMLStreamReader xmlReader) throws XMLStreamException {
        GemsType.Parameters visualParameters = gemsType.getVisualParameters();

        String elementName;

        while(xmlReader.hasNext()) {
            int value = xmlReader.next();

            switch(value) {
                case XMLStreamConstants.START_ELEMENT:
                    elementName = xmlReader.getLocalName();        
                    GemEnum gemEnumStart = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    switch (gemEnumStart) {
                        case COLOR:
                            visualParameters.setColor(getXMLText(xmlReader));
                            break;
                        case TRANSPARENCY:
                            visualParameters.setTransparency(Integer.parseInt(getXMLText(xmlReader)));
                            break;
                        case GEM_CUT:
                            visualParameters.setGemCut(CutType.valueOf(getXMLText(xmlReader).toUpperCase()));
                            break;
                        case FACES:
                            visualParameters.setFaces(Integer.parseInt(getXMLText(xmlReader)));
                            break;
                    }
                    break;
                case XMLStreamConstants.END_ELEMENT:

                    elementName = xmlReader.getLocalName();          
                    GemEnum gemEnumEnd = GemEnum.valueOf(elementName.replace('-','_').toUpperCase());

                    if (gemEnumEnd == GemEnum.FACES) {
                        return visualParameters;
                    }
                    break;
            }
        }
        throw new XMLStreamException("Unknown element in tag Parameters");
    }

   
    private String getXMLText(XMLStreamReader xmlReader) throws XMLStreamException {
        String text = null;
        if (xmlReader.hasNext()) {
            xmlReader.next();
            text = xmlReader.getText();
        }
        return text;
    }

}

