package by.epam.webxml.resource;

import java.util.ResourceBundle;


public class ConfigurationManager {

    private static final ResourceBundle BUNDLE = ResourceBundle.getBundle("config");

    private ConfigurationManager(){}

    public static String getProperty(String key) {
        return BUNDLE.getString(key);
    }
}

