package by.epam.paybank.command.admin_command;

import by.epam.paybank.command.resource_command.CommandException;
import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.entity.Card;
import by.epam.paybank.resource.entity.Client;
import by.epam.paybank.resource.PropertyManager;
import by.epam.paybank.service.AdminService;
import by.epam.paybank.service.ServiceException;
import by.epam.paybank.validator.Validator;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;


public class AdminSupportCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";
    private static final String ATTR_CLIENT_CARDS = "clientCardList";
    private static final String PARAM_CLIENT_ID = "clientId";
    private static final String INCOR_CLIENT_ID = "message.incorClientId";
    private static final String NO_CLIENT = "message.noClient";
    private static final String MESSAGE = "messageSupport";
    private static final String PAGE_CLIENT_LIST = "path.page.clientlist";
    private static final String PAGE_ADMIN_SUP = "path.page.adminsupport";
    private static final String ATTR_CLIENT = "client";

    @Override
    public String execute(HttpServletRequest request) throws CommandException {

        //if session dead
        if (request.getSession(false) == null) {
            return new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        }

        String page;
        String id = request.getParameter(PARAM_CLIENT_ID);

        //check input id, if false -
        if (!Validator.checkId(id)) {
            request.setAttribute(MESSAGE, new PropertyManager(Constants.MESSAGE).getProperty(INCOR_CLIENT_ID));
            page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_CLIENT_LIST);
            return page;
        }

        Client client;
        try {
            client = new AdminService().takeClientById(id);
        } catch (ServiceException e) {
            throw new CommandException("Take client by id service failed.", e);
        }

        //client there is no client with input id
        if (client == null) {
            return showMessage(request, NO_CLIENT);
        }

        //client info would be shown on jsp page
        request.getSession(false).setAttribute(ATTR_CLIENT, client);

        //real id from table 'user'
        int realID;
        try {
            realID = new AdminService().takeTableUserId(client.getId());
        } catch (ServiceException e) {
            throw new CommandException("Take tableUserID service failed.", e);
        }

        //find all client cards
        ArrayList<Card> list;

        try {
            list = new AdminService().takeCards(realID);
        } catch (ServiceException e) {
            throw new CommandException("Take cards service failed.", e);
        }

        request.getSession(false).setAttribute(ATTR_CLIENT_CARDS, list);

        page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_ADMIN_SUP);

        return page;
    }


    //set attribute message to show on page
    private String showMessage(HttpServletRequest request, String message) {
        request.setAttribute(MESSAGE, new PropertyManager(Constants.MESSAGE).getProperty(message));
        String page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_CLIENT_LIST);
        return page;
    }
}
