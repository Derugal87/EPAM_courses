package by.epam.paybank.command.admin_command;

import by.epam.paybank.command.resource_command.CommandException;
import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.entity.Client;
import by.epam.paybank.resource.PropertyManager;
import by.epam.paybank.service.AdminService;
import by.epam.paybank.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;


public class ClientListCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";
    private static final String ATTR_CLIENTS = "clientList";
    private static final String PAGE_CLIENT_LIST = "path.page.clientlist";

    @Override
    public String execute(HttpServletRequest request) throws CommandException {

        //if session dead
        if (request.getSession(false) == null) {
            return new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        }

        ArrayList<Client> clientList;
        try {
            clientList = new AdminService().takeClients();
        } catch (ServiceException e) {
            throw new CommandException("Take clients service failed.", e);
        }

        request.getSession().setAttribute(ATTR_CLIENTS, clientList);

        PropertyManager manager = new PropertyManager(Constants.CONFIG);
        String page = manager.getProperty(PAGE_CLIENT_LIST);

        return page;
    }
}
