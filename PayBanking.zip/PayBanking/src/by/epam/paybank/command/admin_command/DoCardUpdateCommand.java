package by.epam.paybank.command.admin_command;


import by.epam.paybank.command.resource_command.CommandException;
import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.entity.Card;
import by.epam.paybank.resource.PropertyManager;
import by.epam.paybank.service.AdminService;
import by.epam.paybank.service.ServiceException;
import by.epam.paybank.validator.Validator;

import javax.servlet.http.HttpServletRequest;

public class DoCardUpdateCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";
    private static final String UPDATE_CARD = "updateCard";
    private static final String PARAM_VALID = "valid";
    private static final String PARAM_CSC = "csc";
    private static final String PARAM_TYPE = "type";
    private static final String PARAM_CURR = "currency";
    private static final String PARAM_AMOUNT = "amount";
    private static final String PARAM_STATUS = "status";
    private static final String MESSAGE = "msgUpdateCard";
    private static final String PAGE_CARD_UPDATE = "path.page.cardupdate";

    private static final String INCORRECT_VALID_PERIOD = "message.incorValidPeriod";
    private static final String INCORRECT_CSC = "message.incorCsc";
    private static final String INCORRECT_AMOUNT = "message.incorAmount";
    private static final String SUCCESS_UPD_CARD = "message.successUpdCard";

    @Override
    public String execute(HttpServletRequest request) throws CommandException {

        //if session dead
        if (request.getSession(false) == null) {
            return new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        }

        Card card = (Card)request.getSession(false).getAttribute(UPDATE_CARD);

        String valid = request.getParameter(PARAM_VALID);
        String csc = request.getParameter(PARAM_CSC);
        String type = request.getParameter(PARAM_TYPE);
        String currency = request.getParameter(PARAM_CURR);
        String amount = request.getParameter(PARAM_AMOUNT);
        String status = request.getParameter(PARAM_STATUS);

        if (!Validator.checkValid(valid)) {
            return showMessage(request, INCORRECT_VALID_PERIOD);
        }

        if (!Validator.checkCsc(csc)) {
            return showMessage(request, INCORRECT_CSC);
        }

        if (!Validator.checkAmount(amount)) {
            return showMessage(request, INCORRECT_AMOUNT);
        }

        //take bank account id by card number
        int bankAccId;
        try {
            bankAccId = new AdminService().takeAccIdByNumber(String.valueOf(card.getNumber()));
        } catch (ServiceException e) {
            throw new CommandException("Take bank acc id service failed.", e);
        }


        //update card data
        try {
            new AdminService().updateCardData(valid, csc, type, currency, amount, status, bankAccId);
        } catch (ServiceException e) {
            throw new CommandException("Update card data service failed.", e);
        }

        //take update info about card by number
        Card updateCard;
        try {
            updateCard = new AdminService().takeCardByNumber(String.valueOf(card.getNumber()));
        } catch (ServiceException e) {
            throw new CommandException("Take card by number service failed.", e);
        }

        request.getSession(false).setAttribute(UPDATE_CARD, updateCard);

        return showMessage(request, SUCCESS_UPD_CARD);
    }

    //set attribute message to show on page
    private String showMessage(HttpServletRequest request, String message) {
        request.setAttribute(MESSAGE, new PropertyManager(Constants.MESSAGE).getProperty(message));
        return new PropertyManager(Constants.CONFIG).getProperty(PAGE_CARD_UPDATE);
    }
}
