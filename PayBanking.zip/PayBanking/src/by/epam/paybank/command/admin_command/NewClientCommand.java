package by.epam.paybank.command.admin_command;

import by.epam.paybank.command.resource_command.CommandException;
import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.PropertyManager;

import javax.servlet.http.HttpServletRequest;


public class NewClientCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";
    private static final String PAGE_NEW_CLIENT = "path.page.newClient";

    @Override
    public String execute(HttpServletRequest request) throws CommandException {

        //if session dead
        if (request.getSession(false) == null) {
            return new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        }

        String page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_NEW_CLIENT);
        return page;
    }
}
