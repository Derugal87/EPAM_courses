package by.epam.paybank.command.client_command;

import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.PropertyManager;

import javax.servlet.http.HttpServletRequest;


public class ClientInfoCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";
    private static final String PAGE_CLIENT_INFO = "path.page.clientinfo";

    @Override
    public String execute(HttpServletRequest request) {

        //if session dead
        if (request.getSession(false) == null) {
            return new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        }

        PropertyManager manager = new PropertyManager(Constants.CONFIG);
        String page = manager.getProperty(PAGE_CLIENT_INFO);
        return page;
    }
}
