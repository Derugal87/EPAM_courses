package by.epam.paybank.command.client_command;

import by.epam.paybank.command.resource_command.CommandException;
import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.entity.Card;
import by.epam.paybank.resource.PropertyManager;
import by.epam.paybank.service.AdminService;
import by.epam.paybank.service.ClientService;
import by.epam.paybank.service.ServiceException;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;

//Pressing button "New payment"
public class NewPaymentCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";
    private static final String ATTR_CLIENT_ID = "clientId";
    private static final String ATTR_CL_CARDS = "clientCards";
    private static final String PAGE_CLIENT_PAYMENT = "path.page.clientpayment";

    @Override
    public String execute(HttpServletRequest request) throws CommandException {

        //if session dead
        if (request.getSession(false) == null) {
            return new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        }

        int clientId = (Integer)request.getSession(false).getAttribute(ATTR_CLIENT_ID);

        //real id from table 'user'
        int realID;
        try {
            realID = new AdminService().takeTableUserId(clientId);
        } catch (ServiceException e) {
            throw new CommandException("Take tableUserID service failed.", e);
        }

        ArrayList<Card> list;
        try {
            list = new ClientService().takeCards(realID);
        } catch (ServiceException e) {
            throw new CommandException("Take cards service failed.", e);
        }

        request.getSession(false).setAttribute(ATTR_CL_CARDS, list);

        String page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_CLIENT_PAYMENT);

        return page;
    }
}
