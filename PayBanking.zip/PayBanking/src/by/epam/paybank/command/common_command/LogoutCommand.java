package by.epam.paybank.command.common_command;

import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.PropertyManager;

import javax.servlet.http.HttpServletRequest;


public class LogoutCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";

    @Override
    public String execute(HttpServletRequest request) {

        String page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
        request.getSession().invalidate();
        return page;
    }
}
