package by.epam.paybank.command.resource_command;


public class CommandException extends Exception {
    public CommandException(String str) { super(str); }
    public CommandException(Exception e) { super(e); }
    public CommandException(String str, Exception e) { super(str, e); }
}
