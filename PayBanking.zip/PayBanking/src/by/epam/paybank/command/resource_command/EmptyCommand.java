package by.epam.paybank.command.resource_command;

import by.epam.paybank.resource.Constants;
import by.epam.paybank.resource.PropertyManager;

import javax.servlet.http.HttpServletRequest;


public class EmptyCommand implements ICommand {
    private static final String PAGE_INDEX = "path.page.index";

    public String execute(HttpServletRequest request) {
        //no command or strait using controller
        PropertyManager manager = new PropertyManager(Constants.CONFIG);
        String page = manager.getProperty(PAGE_INDEX);
        return page;
    }
}
