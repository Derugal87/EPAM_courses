package by.epam.paybank.controller;

import by.epam.paybank.command.resource_command.CommandException;
import by.epam.paybank.command.resource_command.CommandHelper;
import by.epam.paybank.command.resource_command.ICommand;
import by.epam.paybank.resource.Constants;
import by.epam.paybank.exception.Exception;
import by.epam.paybank.resource.PropertyManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/controller") //no use <servlet> and <servlet-mapping>
public class Controller extends HttpServlet {
    private static final String ATTR_LAST_PAGE = "lastPage";
    private static final String PAGE_INDEX = "path.page.index";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (CommandException e) {
            throw new Exception("Command failed.", e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response)
                                                            throws ServletException, IOException, CommandException {

        String page;                                     //  relative path to jsp page
        CommandHelper helper = CommandHelper.getInstance();
        //obtaining command object to execute request
        ICommand command = helper.selectCommand(request);
        //obtaining jsp page address
        page = command.execute(request);
        //for locale remember last page
        request.getSession().setAttribute(ATTR_LAST_PAGE, page);

        if (page != null) {
            request.getRequestDispatcher(page).forward(request, response);
        } else {
            page = new PropertyManager(Constants.CONFIG).getProperty(PAGE_INDEX);
            response.sendRedirect(request.getContextPath() + page);
        }
    }
}
