package by.epam.paybank.dao;

public class DAOFactory {

    private DAOFactory() { }

    public static ClientDAO takeClientDAO() {
        return ClientDAO.getInstance();
    }

    public static AdminDAO takeAdminDAO() {
        return AdminDAO.getInstance();
    }

    public static UserDAO takeUserDAO() {
        return UserDAO.getInstance();
    }
    public static CommonDAO takeCommonDAO() {
        return CommonDAO.getInstance();
    }
}
