package by.epam.paybank.exception;

import javax.servlet.ServletException;


public class Exception extends ServletException {
    public Exception(String str) { super(str); }
    public Exception(java.lang.Exception e) { super(e); }
    public Exception(String str, java.lang.Exception e) { super(str, e); }
}
