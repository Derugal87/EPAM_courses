package by.epam.paybank.resource.entity;

public enum UserType {
    CLIENT, ADMIN, GUEST
}
