package by.epam.paybank.service;


import by.epam.paybank.dao.DAOException;
import by.epam.paybank.dao.DAOFactory;
import by.epam.paybank.resource.entity.Card;
import by.epam.paybank.resource.entity.Client;
import by.epam.paybank.resource.PasswordMD5;

import java.util.ArrayList;

public class AdminService extends CommonService implements IAdminService {

    @Override
    public ArrayList<Client> takeClients() throws ServiceException {
        ArrayList<Client> clients = null;
        try {
            clients = DAOFactory.takeAdminDAO().takeClients();
        } catch (DAOException e) {
            throw new ServiceException("Take clients list dao failed.", e);
        }
        return clients;
    }

    @Override
    public ArrayList<Card> takeCards() throws ServiceException {
        ArrayList<Card> cards = null;
        try {
            cards = DAOFactory.takeAdminDAO().takeCards();
        } catch (DAOException e) {
            throw new ServiceException("Take cards list dao failed.", e);
        }
        return cards;
    }

    @Override
    public void unblockCard(String cardNumber) throws ServiceException {

        try {
            DAOFactory.takeAdminDAO().unblockCard(cardNumber);
        } catch (DAOException e) {
            throw new ServiceException("Ublocking card dao failed.", e);
        }
    }

    @Override
    public void regNewClient(String name, String surname, String passport, String address,
                             String login, String password) throws ServiceException {

        String hidePassword = new PasswordMD5().makeHash(password);                          //password   MD5

        try {
            DAOFactory.takeAdminDAO().regNewClient(name, surname, passport, address, login, hidePassword);
        } catch (DAOException e) {
            throw new ServiceException("New client registration info dao failed.", e);
        }
    }

    @Override
    public boolean checkCard(String cardNumber) throws ServiceException {
        boolean isCardExist = false;
        try {
            isCardExist = DAOFactory.takeAdminDAO().checkCard(cardNumber);
        } catch (DAOException e) {
            throw new ServiceException("Check card by number dao failed.", e);
        }
        return isCardExist;
    }

    @Override
    public void regNewCard(String cardNumber, String valid, String csc, String type,
                                                            String currency, String amount) throws ServiceException {

        try {
            DAOFactory.takeAdminDAO().regNewCard(cardNumber, valid, csc, type, currency, amount);
        } catch (DAOException e) {
            throw new ServiceException("New card registration dao failed.", e);
        }
    }

    @Override
    public Client takeClientById(String id) throws ServiceException {
        Client client;
        try {
            client = DAOFactory.takeAdminDAO().takeClientById(id);
        } catch (DAOException e) {
            throw new ServiceException("Take client by id dao failed.", e);
        }
        return client;
    }

    @Override
    public void deleteCard(String cardNumber) throws ServiceException {
        try {
            DAOFactory.takeAdminDAO().deleteCard(cardNumber);
        } catch (DAOException e) {
            throw new ServiceException("Delete card by card number dao failed.", e);
        }
    }

    @Override
    public boolean checkClient(String clientId) throws ServiceException {
        boolean isClientExist;
        try {
            isClientExist = DAOFactory.takeAdminDAO().checkClient(clientId);
        } catch (DAOException e) {
            throw new ServiceException("Check client by id dao failed.", e);
        }
        return isClientExist;
    }

    @Override
    public void deleteClient(int clientRealId) throws ServiceException {
        try {
            DAOFactory.takeAdminDAO().deleteClient(clientRealId);
        } catch (DAOException e) {
            throw new ServiceException("Delete client by user.id dao failed.", e);
        }
    }

    @Override
    public void updateClientData(int infoId, String name, String surname, String passport, String address,
                             String login, String password) throws ServiceException {

        String hidePassword = new PasswordMD5().makeHash(password);                          //password   MD5

        try {
            DAOFactory.takeAdminDAO().updateClientData(infoId, name, surname, passport, address,
                    login, hidePassword);
        } catch (DAOException e) {
            throw new ServiceException("Update client data dao failed.", e);
        }
    }

    @Override
    public void updateCardData(String valid, String csc, String type, String currency,
                                    String amount, String status, int bankAccId) throws ServiceException {
        try {
            DAOFactory.takeAdminDAO().updateCardData(valid, csc, type, currency,
                    amount, status, bankAccId);
        } catch (DAOException e) {
            throw new ServiceException("Update card data dao failed.", e);
        }
    }


}
