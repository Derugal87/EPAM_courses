package by.epam.paybank.service;

import by.epam.paybank.dao.DAOException;
import by.epam.paybank.dao.DAOFactory;
import by.epam.paybank.resource.entity.Card;

import java.math.BigDecimal;


public class ClientService extends CommonService implements IClientService{

    @Override
    public void blockCard(String cardNumber) throws ServiceException {

        try {
            DAOFactory.takeClientDAO().blockCard(cardNumber);
        } catch (DAOException e) {
            throw new ServiceException("Blocking client card dao failed.", e);
        }
    }

    @Override
    public void updateBankAccaunt(int accountId, BigDecimal newAmount) throws ServiceException {
        try {
            DAOFactory.takeClientDAO().updateBankAccaount(accountId, newAmount);
        } catch (DAOException e) {
            throw new ServiceException("Update after payment dao failed.", e);
        }
    }

    @Override
    public void makeTransfer(Card fromCard, Card toCard, int fromAccountId,
                             int toAccountId, BigDecimal amount) throws ServiceException {

        //calculate what amount should be write to db
        BigDecimal fromAmount = fromCard.getSumm().subtract(amount);
        BigDecimal toAmount = toCard.getSumm().add(amount);

        try {
            DAOFactory.takeClientDAO().makeTransfer(fromAccountId, toAccountId, fromAmount, toAmount);
        } catch (DAOException e) {
            throw new ServiceException("Card transfer dao failed.", e);
        }
    }


}
