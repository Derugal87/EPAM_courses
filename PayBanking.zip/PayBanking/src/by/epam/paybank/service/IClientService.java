package by.epam.paybank.service;

import by.epam.paybank.resource.entity.Card;

import java.math.BigDecimal;


public interface IClientService {

    void blockCard(String cardNumber) throws ServiceException;
    void updateBankAccaunt(int accountId, BigDecimal newAmount) throws ServiceException;
    void makeTransfer(Card fromCard, Card toCard, int fromAccountId,
                                                int toAccountId, BigDecimal amount) throws ServiceException;
}
