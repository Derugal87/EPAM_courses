package by.epam.paybank.service;


import by.epam.paybank.resource.entity.Client;
import by.epam.paybank.resource.entity.UserType;

public interface ILoginService {
    UserType checkLogin(String login, String password) throws ServiceException;
    Client takeClient(String login, String password) throws ServiceException;
}
