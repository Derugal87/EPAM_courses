package test.by.epam.paybank.initconpool;

import org.junit.Assert;
import org.junit.Test;
import by.epam.paybank.pool.ConnectionPool;

public class InitConnectionPoolTest {

    private static int ACTUAL_CONNECTION = 15;

   @Test
    public void checkConnectionNumber() {

        int expectedConnection = ConnectionPool.getInstance().getPoolSize();


        Assert.assertEquals("Test failed. Connection number is " + expectedConnection,
                                                                        expectedConnection, ACTUAL_CONNECTION);
    }
}
